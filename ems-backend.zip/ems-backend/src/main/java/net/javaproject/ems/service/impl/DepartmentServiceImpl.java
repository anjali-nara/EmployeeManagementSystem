package net.javaproject.ems.service.impl;

import lombok.AllArgsConstructor;
import net.javaproject.ems.dto.DepartmentDto;
import net.javaproject.ems.entity.Department;
import net.javaproject.ems.exception.ResourceNotFoundException;
import net.javaproject.ems.mapper.DepartmentMapper;
import net.javaproject.ems.respository.DepartmentRepository;
import net.javaproject.ems.service.DepartmentService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class DepartmentServiceImpl implements DepartmentService {

    private DepartmentRepository departmentRepository;

    @Override
    public DepartmentDto createDepartment(DepartmentDto departmentDto) {
        Department department = DepartmentMapper.mapToDepartment(departmentDto);
        Department savedDepartment =departmentRepository.save(department);
        return DepartmentMapper.mapToDepartmentDto(savedDepartment);
    }

    @Override
    public DepartmentDto getDepartmentById(Long departmentId) {
        Department department=departmentRepository.findById(departmentId).orElseThrow(
                ()-> new ResourceNotFoundException("Department with given ID does not exist" + departmentId));
        return DepartmentMapper.mapToDepartmentDto(department);
    }

    @Override
    public List<DepartmentDto> getAllDepartments() {
        List<Department> departments = departmentRepository.findAll();
        return departments.stream().map((department) -> DepartmentMapper.mapToDepartmentDto(department))
                .collect(Collectors.toList());
    }

    @Override
    public DepartmentDto updateDepartment(Long departmentId, DepartmentDto updatedDepartment) {
        Department department=departmentRepository.findById(departmentId).orElseThrow(
                ()-> new ResourceNotFoundException("Department with given Id does not exist" + departmentId));
        department.setDepartmentName(updatedDepartment.getDepartmentName());
        department.setDepartmentDescription(updatedDepartment.getDepartmentDescription());
        Department updatedDepartmentObj=departmentRepository.save(department);
        return DepartmentMapper.mapToDepartmentDto(updatedDepartmentObj);
    }

    @Override
    public void deleteDepartment(Long departmentId) {
        Department department=departmentRepository.findById(departmentId).orElseThrow(
                ()->new ResourceNotFoundException("Department with give Id does not exist"+ departmentId));
        departmentRepository.deleteById(departmentId);
    }


}
